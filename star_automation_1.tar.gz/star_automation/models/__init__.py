# -*- coding: utf-8 -*-
from . import res_users
from . import crm
from . import service_agreement
